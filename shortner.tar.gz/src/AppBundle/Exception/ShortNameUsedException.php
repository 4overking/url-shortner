<?php

namespace AppBundle\Exception;

class ShortNameUsedException extends \RuntimeException
{
}
