<?php

namespace AppBundle\Exception;

class HostUnavailableException extends \RuntimeException
{
}
